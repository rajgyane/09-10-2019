import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { ServicesService } from '../../auth/services.service';
import  lead  from '../../model/lead';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.css']
})
export class ViewdetailsComponent implements OnInit {
  Lead:lead[]= [];
  show=true;

  constructor(public dialogRef: MatDialogRef<lead>,@Inject(MAT_DIALOG_DATA)public data: any,private ls:ServicesService) { }

  ngOnInit() {
    console.log(this.data.id);
    this.ls
      .getDetails(this.data.id)
      .subscribe((data: lead[]) => {
        this.Lead = data;
        this.show=false;
        console.log(this.Lead);
       });
    //console.log(this.data.id);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  

}
