import { Component, OnInit ,Inject} from '@angular/core';
import {  MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { Followupstatus} from '../../model/followupstatus';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {ServicesService} from '../../auth/services.service';
@Component({
  selector: 'app-editfollowupstatuslist',
  templateUrl: './editfollowupstatuslist.component.html',
  styleUrls: ['./editfollowupstatuslist.component.css']
})
export class EditfollowupstatuslistComponent implements OnInit {
  angForm: FormGroup;
  response:string;
  followup_status_data:Followupstatus[]=[];
  constructor(public dialogRef: MatDialogRef<Followupstatus>,@Inject(MAT_DIALOG_DATA) public data: any,public fb:FormBuilder,private ls:ServicesService)
   {this.createForm();  }
   createForm() {
    this.angForm = this.fb.group({
      
      followupstatus: ['', Validators.required ]
      
    });
  }

  ngOnInit() {
    
    this.ls
    .edit_followupstatus_data(this.data.id)
    .subscribe((data: Followupstatus[]) => {
      this.followup_status_data = data;
      this.angForm.patchValue({followupstatus:'1'});
      //console.log( this.followup_status_data);
     });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  edit_followups(value)
  {
    let change_value=value;
    let action_id=this.data.id;
    this.ls
    .edit_followups_update(change_value,action_id)
    .subscribe((data: any) => {
      this.response = data;
      //console.log(this.response);
      
     });
    


  }

}
