export class RoleType {
    role_id:string;   
    role_name:string;
    role_status:number;

}
