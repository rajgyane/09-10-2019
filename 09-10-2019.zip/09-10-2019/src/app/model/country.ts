export class Country
 {
    Country:string;
    code:string;
 }
