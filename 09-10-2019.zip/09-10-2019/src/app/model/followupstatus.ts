export class Followupstatus {
    status_id:string;
    status_name:string;
}
