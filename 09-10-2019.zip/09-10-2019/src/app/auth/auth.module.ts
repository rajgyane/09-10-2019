import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './login/login.component';
import {MaterialModule} from '../material/material.module';
import{ ReactiveFormsModule,FormsModule} from '@angular/forms';


@NgModule({
  declarations: [LoginComponent],
  imports: [
    CommonModule,BrowserModule,MaterialModule, ReactiveFormsModule,FormsModule,
    AuthRoutingModule
  ]
})
export class AuthModule { }
